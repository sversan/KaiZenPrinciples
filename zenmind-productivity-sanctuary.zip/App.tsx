
import React from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import PomodoroTimer from './components/PomodoroTimer';
import IkigaiSection from './components/IkigaiSection';
import HarahachibuMonitor from './components/HarahachibuMonitor';
import KaizenSection from './components/KaizenSection';
import ShinrinYokuSection from './components/ShinrinYokuSection';
import NemawashiSection from './components/NemawashiSection';
import { AppView } from './types';

const App: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-slate-50 text-slate-900 scroll-smooth">
      <Navigation currentView={AppView.DASHBOARD} />
      
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto p-6 md:p-12 space-y-24 pb-48">
          {/* Dashboard Header */}
          <section id="dashboard" className="scroll-mt-12">
            <Dashboard />
          </section>

          {/* Core Tools Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <section id="pomodoro" className="scroll-mt-12 flex flex-col justify-center">
              <PomodoroTimer />
            </section>
            
            <section id="harahachibu" className="scroll-mt-12">
              <HarahachibuMonitor />
            </section>
          </div>

          {/* Full Width Sections */}
          <section id="kaizen" className="scroll-mt-12">
            <KaizenSection />
          </section>

          <section id="ikigai" className="scroll-mt-12 pt-12 border-t border-slate-200/60">
            <IkigaiSection />
          </section>

          <section id="nemawashi" className="scroll-mt-12 pt-12 border-t border-slate-200/60">
            <NemawashiSection />
          </section>

          <section id="shinrin_yoku" className="scroll-mt-12 pt-12 border-t border-slate-200/60">
            <ShinrinYokuSection />
          </section>
          
          {/* Footer Zen Quote */}
          <footer className="text-center pt-24 opacity-40 hover:opacity-100 transition-opacity">
            <p className="font-serif italic text-slate-500">"The best time to plant a tree was 20 years ago. The second best time is now."</p>
          </footer>
        </div>
      </main>
    </div>
  );
};

export default App;
