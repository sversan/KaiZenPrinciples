
import { GoogleGenAI, Type } from "@google/genai";
import { IkigaiData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const geminiService = {
  async getDailyZenQuote(): Promise<string> {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate a short, powerful Japanese zen proverb or productivity quote (with English translation) that inspires mindfulness and consistent effort.",
    });
    return response.text || "Small progress is still progress.";
  },

  async suggestKaizen(currentLog: string[]): Promise<string> {
    const prompt = `Based on these recent improvements: ${currentLog.join(', ')}. Suggest one very small (1%) improvement I can make today to my productivity or wellbeing. Keep it actionable and tiny.`;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Try taking a 5-minute deep breathing break.";
  },

  async analyzeIkigai(data: IkigaiData): Promise<string> {
    const prompt = `
      I have filled out my Ikigai chart:
      What I Love: ${data.love.join(', ')}
      What I'm Good At: ${data.goodAt.join(', ')}
      What the World Needs: ${data.worldNeeds.join(', ')}
      What I can be Paid For: ${data.paidFor.join(', ')}
      
      Suggest 3 potential career paths or life focuses that intersect these areas. Be creative and encouraging.
    `;
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Focus on finding the intersection of your talents and the world's needs.";
  },

  async planNemawashi(decision: string): Promise<string[]> {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a list of 5 concrete "Nemawashi" (groundwork) steps for the following decision: "${decision}". Output the steps as a JSON list of strings.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    try {
      return JSON.parse(response.text);
    } catch (e) {
      return ["Identify key stakeholders", "Gather initial feedback", "Prepare data", "Schedule one-on-ones", "Draft a proposal"];
    }
  }
};
